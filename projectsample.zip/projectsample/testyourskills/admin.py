from django.contrib import admin
from models import CourseTest,Questionary

# Register your models here.

class CourseTestCustomAdmin(admin.ModelAdmin):
    pass

class QuestionaryAdmin(admin.ModelAdmin):
    pass

admin.site.register(CourseTest, CourseTestCustomAdmin)

admin.site.register(Questionary, QuestionaryAdmin)
