from __future__ import unicode_literals

from django.db import models

# Create your models here.

class CourseTest(models.Model):
    title = models.CharField(max_length=200)
    duration = models.IntegerField()
    desc = models.TextField(default="Testing your skills")

class Questionary(models.Model):
    course_test = models.ForeignKey(to=CourseTest)
    question = models.CharField(max_length=200)