from django.contrib import admin
from models import Course, CourseContent


# Register your models here.
#
def deactivate_course(modeladmin, reqeust, queryset):
    for course in queryset:
        course.status='D'
        course.save()
    #queryset.update(status='D')

def activate_course(modeladmin, reqeust, queryset):
    for course in queryset:
        course.status='A'
        course.save()
    #queryset.update(status='A')

class CourseContentInline(admin.TabularInline):
    model = CourseContent

class CourseContentAdmin(admin.ModelAdmin):
   list_display = ("content_title",)

class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'duration', 'price', 'status',  'image_tag')
    actions = [deactivate_course, activate_course]
    inlines = [
        CourseContentInline,
    ]



admin.site.register(Course, CourseAdmin)
admin.site.register(CourseContent,CourseContentAdmin)

