from __future__ import unicode_literals
from tinymce import models as tinymce_models
from django.db import models
from django.contrib.auth.models import User

import django.contrib.auth
# Create your models here.
#
# class Question(models.Model):
#     question_text = models.CharField(max_length=200)
#     pub_date = models.DateTimeField('date published')
from django.utils.safestring import mark_safe


class Course(models.Model):
    title = models.CharField(max_length=200)
    duration = models.IntegerField()
    desc = models.TextField(default="This is course default")
    price = models.FloatField(default=0.0)
    thumb = models.ImageField(upload_to="thumbs", null=True)
    status = models.CharField(default='D', max_length=1)

    def image_tag(self):
        if self.thumb:
            return mark_safe('<img src="/%s" style="width: 150px;" />' % self.thumb.url)
        else:
            return 'No Image Found'

class CourseContent(models.Model):
    course = models.ForeignKey(Course)
    content_title = tinymce_models.HTMLField()


class Faq(models.Model):
    question_text = models.CharField(max_length=200)
    answer_text = models.TextField(default="Please provide and answer!")


class WishList(models.Model):
    user = models.ForeignKey(User)
    course = models.ForeignKey(Course)


