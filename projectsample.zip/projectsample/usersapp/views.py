from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from django.shortcuts import render
from django.http import HttpResponse
from django.core.handlers.wsgi import WSGIRequest
from .models import Course

from datetime import date



from django.views.decorators.csrf import csrf_exempt
from django.template.loader import render_to_string


# Create your views here.

def index(request):

    # Businees logic
    courses = Course.objects.all()
    if request.user.is_authenticated:
        print request.user.id
    html_str = render_to_string('dashboard.html', {"courses": courses})
    return HttpResponse(html_str)

def signin(request):


    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            # Sessions
            login(request, user)
            request.session['userlogintime'] = str(date.today())
            return redirect(index)
        else:
           pass

    if request.method == "GET":
        html_str = render_to_string('signin.html', {} ,request=request)
        return HttpResponse(html_str)

def lookforsession(request):
    user = request.user
    if(user is not None):
        pass
    user_login_in = request.session.get('userlogintime')
    return HttpResponse('user found:'+ str(user_login_in))

def logout_view(request):
    logout(request)
    return HttpResponse('user logedout')




def signup(request):
    return HttpResponse('<img src=""> <input type="text" name="username" text="email"/>'
                        '<input type="password" name="password" text="password"/>  <input type="submit" name="signup"/>')


@csrf_exempt
def course_details(request, course_id, user_id):
    """
    :type request:django.core.handlers.wsgi.WSGIRequest
    """

    if request.method == "GET":
        return HttpResponse("It's get , Course detailes for:{},{}".format(course_id,user_id))

    if request.method == "POST":
        return HttpResponse("it is post:username:%s, password:%s"%(request.POST['username'],
                                                                   request.POST['password']))

    if request.method == "PUT":
        return HttpResponse("it is PUT:")

    if request.method == "DELETE":
        return HttpResponse("it is DELETE:")





