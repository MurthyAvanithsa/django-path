from . import views
from django.conf.urls import url

from django.contrib.auth import views as auth_views

urlpatterns = [
    url(r'^dashboard/', views.index),
    url(r'^signup/', views.signup),
    url(r'^signin/', views.signin),
    url(r'^course/(\d{1,9})/(\d{1,9})/', views.course_details),
    url(r'^sessiontest/', views.lookforsession),
    url(r'^logout/', views.logout_view),
]